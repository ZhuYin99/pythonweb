#!/usr/bin/env python
# -*- coding: UTF-8 -*-

from distutils.core   import setup
import sys

# 产品版本
revision = "1.0.0.0"

if sys.platform == 'win32':
  # 检查命令行参数
  if len(sys.argv) == 1:
      sys.argv.append("py2exe")
      sys.argv.append("-q")
 
  from py2exe.build_exe import py2exe    
  setup(
    platforms        = ['Windows'],
    version          = revision,
    description      = "Chinese chess",
    name             = "Chinese chess", 
    long_description = "Chinese chess",
    url              = "www.cnblogs.com/stuarts",     
    maintainer       = 'stuarts',
    maintainer_email = 'stuarts740@gmail.com',
    zipfile          = None, # 不生成library.zip  
    windows = [
      {
        "script": "ChsChess.py",
        "icon_resources": [
          (0, "ChsChess.ico"),
         ]       
      }
    ],
    data_files = [('BMP', \
        [ \
        r'.\BMP\b_bing.bmp',  \
        r'.\BMP\b_jiang.bmp',  \
        r'.\BMP\b_ju.bmp',  \
        r'.\BMP\b_ma.bmp',  \
        r'.\BMP\b_pao.bmp',  \
        r'.\BMP\b_shi.bmp',  \
        r'.\BMP\b_xiang.bmp',  \
        r'.\BMP\curPos.bmp',  \
        r'.\BMP\ground.bmp',  \
        r'.\BMP\r_bing.bmp',  \
        r'.\BMP\r_jiang.bmp',  \
        r'.\BMP\r_ju.bmp',  \
        r'.\BMP\r_ma.bmp',  \
        r'.\BMP\r_pao.bmp',  \
        r'.\BMP\r_shi.bmp',  \
        r'.\BMP\r_xiang.bmp',  \
        ] \
        )],
    options = {
      "py2exe":{
        "compressed"  : 1,
        "includes"    : ["sip"],
        "optimize"    : 2,
        "bundle_files": 1 # python, Qt等dll放入library
      },
    }
  )
